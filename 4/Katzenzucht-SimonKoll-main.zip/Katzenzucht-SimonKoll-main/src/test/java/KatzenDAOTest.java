/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import dao.KatzenDAO;
import model.Impfstoff;
import model.Impfung;
import model.Katze;
import model.Rasse;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/**
 * @author aisge
 */
public class KatzenDAOTest {

    private static final String PU = "KatzenzuchtTestPU";
    KatzenDAO dao = null;

    public KatzenDAOTest() {
    }

    @BeforeEach
    public void setUp() {
        dao = new KatzenDAO(PU);

        dao.startTransaction();
        initRassen();
        initImpfstoffe();
        initKatzen();
        initImpfungen();
        dao.commit();
    }

    private void initRassen() {
        Rasse britKurzhaar = dao.createRasse("Britisch Kurzhaar");
        Rasse maineCoon = dao.createRasse("Maine Coon");
    }

    private void initImpfstoffe() {
        Impfstoff i1 = dao.createImpfstoff("Grundimmunisierung 1", 3);
        Impfstoff i2 = dao.createImpfstoff("Grundimmunisierung 2", 50);
        Impfstoff i3 = dao.createImpfstoff("Tollwut", 200);
    }

    private void initKatzen() {
        Rasse bk = dao.getRasse(1);
        Katze k1 = dao.createKatze("Großvati", bk, null, null, parseDate("02.02.2000"), 'm');
        Katze k2 = dao.createKatze("Omi", bk, null, null, parseDate("05.03.2001"), 'w');

        Katze k12_1 = dao.createKatze("Susi", bk, k2, k1, parseDate("07.05.2003"), 'm');
        Katze k12_2 = dao.createKatze("Tom", bk, k2, k1, parseDate("07.05.2003"), 'w');
    }

    private void initImpfungen() {
        Katze k1 = dao.getKatze("Großvati");
        Katze k2 = dao.getKatze("Omi");

        Impfstoff i1 = dao.getImpfstoff(1L);
        Impfstoff i2 = dao.getImpfstoff(2L);

        dao.createImpfung(k1, i1, parseDate("15.04.2000"));
        dao.createImpfung(k1, i2, parseDate("12.05.2000"));

        dao.createImpfung(k2, i1, parseDate("07.05.2001"));
        dao.createImpfung(k2, i2, parseDate("10.06.2001"));
    }

    private LocalDate parseDate(String s) {
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd.MM.yyyy");
        return LocalDate.parse(s, dtf);
    }

    @AfterEach
    public void tearDown() {
        dao.close();
    }

    /**
     * Test of createRasse method, of class KatzenDAO.
     */
    @Test
    public void testGetRasse() {
        Rasse r = dao.getRasse(1);
        Assertions.assertEquals("Britisch Kurzhaar", r.getBezeichnung());

        r = dao.getRasse(2);
        assertEquals("Maine Coon", r.getBezeichnung());
    }

    /**
     * Test of createImpfstoff method, of class KatzenDAO.
     */
    @Test
    public void testCreateImpfstoff() {
        Impfstoff i1 = dao.getImpfstoff(1);
        assertEquals(3, i1.getGueltigkeit());

        Impfstoff i2 = dao.getImpfstoff(2);
        assertEquals("Grundimmunisierung 2", i2.getBezeichnung());
    }

    /**
     * Test of createKatze method, of class KatzenDAO.
     */
    @Test
    public void testCreateKatze() {
        Katze k1 = dao.getKatze("Großvati");
        assertTrue(k1.getMutter() == null);

        Katze k12_1 = dao.getKatze("Susi");
        assertEquals(parseDate("07.05.2003"), k12_1.getGebDatum());
        assertEquals(parseDate("02.02.2000"), k12_1.getVater().getGebDatum());
    }

    /**
     * Test of createImpfung method, of class KatzenDAO.
     */
    @Test
    public void testGetImpfung() {
        Impfung i1 = dao.getImpfung(1);
        assertEquals("Großvati", i1.getKatze().getName());
    }

    @Test
    public void testBidirectional() {
        Katze k1 = dao.getKatze("Großvati");
        assertEquals(2, k1.getImpfungen().size());

        Impfstoff i1 = dao.getImpfstoff(1);
        assertEquals(2, i1.getImpfungen().size());
    }

    @Test
    public void testRassenstatistik() {
        List<Object[]> list = dao.getRassenstatistik();
        assertEquals(2, list.size());
        assertEquals(0L, list.get(1)[1]);
        assertEquals(4L, list.get(0)[1]);
    }

    @Test
    public void testLetzteImpfungen() {
        List<Object[]> list = dao.getLetzteImpfungen();
        assertNull(list.get(0)[2]);
        assertNull(list.get(1)[2]);
        assertEquals("Omi", list.get(2)[0]);
        assertEquals(parseDate("10.06.2001"), list.get(2)[1]);
        assertEquals("Grundimmunisierung 2", list.get(2)[2]);
        printObjectArrayList(list);
    }

    private void printObjectArrayList(List<Object[]> list) {
        System.out.println("Anzahl: " + list.size());
        for (Object[] o : list) {
            for (Object od : o) {
                System.out.print(od + ";");
            }
            System.out.println();
        }
    }
}
