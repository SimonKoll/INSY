package dao;

import java.time.LocalDate;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.*;

import model.Impfstoff;
import model.Impfung;
import model.Katze;
import model.Rasse;

/**
 *
 * @author aisge
 */
public class KatzenDAO {

    EntityManagerFactory emf;
    EntityManager em;

    public KatzenDAO(String pu) {
        emf = Persistence.createEntityManagerFactory(pu);
        em = emf.createEntityManager();
    }

    public void startTransaction() {
        em.getTransaction().begin();
    }

    public void commit() {
        em.getTransaction().commit();
    }

    public void rollback() {
        em.getTransaction().rollback();
    }

    public Rasse createRasse(String bezeichnung) {
        Rasse r = new Rasse();
        r.setBezeichnung(bezeichnung);
        em.persist(r);
        return r;
    }

    public Rasse getRasse(long id) {
        return em.find(Rasse.class, id);
    }

    public Impfstoff createImpfstoff(String bezeichnung, long gueltigkeit) {
        Impfstoff i = new Impfstoff();
        i.setBezeichnung(bezeichnung);
        i.setGueltigkeit(gueltigkeit);
        em.persist(i);
        return i;
    }

    public Impfstoff getImpfstoff(long id) {
        return em.find(Impfstoff.class, id);
    }

    public Katze createKatze(String name, Rasse rasse, Katze mutter, Katze vater,
                             LocalDate gebDatum, char geschlecht) {
        Katze katze = new Katze();
        katze.setName(name);
        katze.setRasse(rasse);
        katze.setMutter(mutter);
        katze.setVater(vater);
        katze.setGebDatum(gebDatum);
        katze.setGeschlecht(geschlecht);
        rasse.getKatzen().add(katze);
        em.persist(katze);
        return katze;
    }

    public Katze getKatze(String name) {
        return em.find(Katze.class, name);
    }

    public Impfung createImpfung(Katze katze, Impfstoff impfstoff, LocalDate datum) {
        // TODO implementieren!!
        Impfung impfung = new Impfung();
        impfung.setKatze(katze);
        impfung.setImpstoff(impfstoff);
        impfung.setDatum(datum);
        katze.getImpfungen().add(impfung);
        impfstoff.getImpfungen().add(impfung);
        em.persist(impfung);

        return impfung;
    }

    public Impfung getImpfung(long id) {
        return em.find(Impfung.class, id);
    }

    /**
     * Liefert alle Rassen zurück und die Anzahl an zugehörigen Katzen.
     * Implementiert mittels Criteria API
     *
     * @return List<[Bezeichnung], [Anzahl]>
     */
    public List<Object[]> getRassenstatistik() {
        // TODO implementieren
        CriteriaBuilder cb = em.getCriteriaBuilder();
        CriteriaQuery<Object[]> cq = cb.createQuery(Object[].class);

        Root<Rasse> rasse = cq.from(Rasse.class);
        Join j = rasse.join("katzen", JoinType.LEFT);

        cq.multiselect(rasse.get("bezeichnung"), cb.count(j.get("name")));
        cq.groupBy(rasse.get("bezeichnung"));
        cq.orderBy(cb.desc(cb.count(j.get("name"))));

        TypedQuery<Object[]> query = em.createQuery(cq);

        return query.getResultList();
    }

    /**
     * Liefert alle Katzen und das Datum und Impfstoff der jeweils letzten
     * Impfung
     *
     * @return List<[Name], [Datum], [Impfstoffbezeichnung]>
     */
    public List<Object[]> getLetzteImpfungen() {
        // TODO implementieren!

        TypedQuery<Object[]> query = em.createNamedQuery(Katze.FINDALL, Object[].class);

        return query.getResultList();
    }

    public void close() {
        em.close();
        emf.close();
    }
}
