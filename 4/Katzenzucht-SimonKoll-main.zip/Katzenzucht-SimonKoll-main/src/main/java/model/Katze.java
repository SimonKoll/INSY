package model;

import javax.persistence.*;
import java.io.Serializable;
import java.time.LocalDate;
import java.util.LinkedList;
import java.util.List;

/**
 * @author aisge
 */
@Entity
@NamedQuery(name=Katze.FINDALL, query="SELECT k.name, i.datum, im.bezeichnung FROM Katze k LEFT JOIN k.impfungen i LEFT JOIN i.impfstoff im WHERE i.datum >= ALL (SELECT imp.datum FROM Impfung imp WHERE imp.katze=k) ORDER BY i.datum DESC")
public class Katze implements Serializable {

    private static final long serialVersionUID = 1L;
    public static final String FINDALL = "Katze.findAll";

    // TODO name als Primary Key definieren
    @Id
    private String name;

    @ManyToOne
    private Rasse rasse;

    @ManyToOne
    private Katze mutter;

    @ManyToOne
    private Katze vater;

    @OneToMany
    private List<Impfung> impfungen;

    @Column
    private LocalDate gebDatum;

    private char geschlecht = '-';

    public Katze() {
        impfungen = new LinkedList<>();
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Rasse getRasse() {
        return rasse;
    }

    public void setRasse(Rasse rasse) {
        this.rasse = rasse;
    }

    public Katze getMutter() {
        return mutter;
    }

    public void setMutter(Katze mutter) {
        this.mutter = mutter;
    }

    public Katze getVater() {
        return vater;
    }

    public void setVater(Katze vater) {
        this.vater = vater;
    }

    public LocalDate getGebDatum() {
        return gebDatum;
    }

    public void setGebDatum(LocalDate gebDatum) {
        this.gebDatum = gebDatum;
    }

    public char getGeschlecht() {
        return geschlecht;
    }

    public void setGeschlecht(char geschlecht) {
        this.geschlecht = geschlecht;
    }

    public List<Impfung> getImpfungen() {
        return impfungen;
    }

    public void setImpfungen(List<Impfung> impfungen) {
        this.impfungen = impfungen;
    }
}
