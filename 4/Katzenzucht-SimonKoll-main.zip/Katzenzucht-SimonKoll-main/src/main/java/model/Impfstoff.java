package model;

import javax.persistence.*;
import java.io.Serializable;
import java.util.LinkedList;
import java.util.List;

/**
 * @author aisge
 */
@Entity
public class Impfstoff implements Serializable {

    private static final long serialVersionUID = 1L;

    // ToDo id automatisch vergeben, dazu soll eine Sequence mit dem Namen "Impfstoff_SEQ" angelegt werden
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "Impfstoff_SEQ")
    private Long id;

    @Column(length = 30, nullable = false)
    private String bezeichnung;

    private long gueltigkeit;

    @OneToMany
    private List<Impfung> impfungen;

    public Impfstoff() {
        impfungen = new LinkedList<>();
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getBezeichnung() {
        return bezeichnung;
    }

    public void setBezeichnung(String bezeichnung) {
        this.bezeichnung = bezeichnung;
    }

    public long getGueltigkeit() {
        return gueltigkeit;
    }

    public void setGueltigkeit(long gueltigkeit) {
        this.gueltigkeit = gueltigkeit;
    }

    public List<Impfung> getImpfungen() {
        return impfungen;
    }

    public void setImpfungen(List<Impfung> impfungen) {
        this.impfungen = impfungen;
    }
}
