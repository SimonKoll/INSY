package model;

import javax.persistence.*;
import java.io.Serializable;
import java.time.LocalDate;

/**
 * @author aisge
 */
@Entity
public class Impfung implements Serializable {

    private static final long serialVersionUID = 1L;

    // TODO id autom. vergeben, dazu soll eine Sequence mit dem Namen "Impfung_SEQ" angelegt werden
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "Impfung_SEQ")
    private Long id;

    @Column
    private LocalDate datum;

    @ManyToOne(fetch = FetchType.LAZY)
    private Katze katze;

    @ManyToOne(fetch = FetchType.LAZY)
    private Impfstoff impfstoff;

    public Impfung() {}

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public LocalDate getDatum() {
        return datum;
    }

    public void setDatum(LocalDate datum) {
        this.datum = datum;
    }

    public Katze getKatze() {
        return katze;
    }

    public void setKatze(Katze katze) {
        this.katze = katze;
    }

    public Impfstoff getImpfstoff() {
        return impfstoff;
    }

    public void setImpstoff(Impfstoff impfstoff) {
        this.impfstoff = impfstoff;
    }
}
