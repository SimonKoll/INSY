package model;

import java.io.Serializable;
import java.util.LinkedList;
import java.util.List;
import javax.persistence.*;

/**
 *
 * @author aisge
 */
@Entity
public class Rasse implements Serializable {

    private static final long serialVersionUID = 1L;

    // TODO id autom. vergeben, dazu soll eine Sequence mit dem Namen "Rasse_SEQ" angelegt werden
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "Rasse_SEQ")
    private Long id;

    @Column(length = 30, nullable = false)
    private String bezeichnung;

    @OneToMany
    private List<Katze> katzen;

    public Rasse() {
        this.katzen = new LinkedList<Katze>();
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getBezeichnung() {
        return bezeichnung;
    }

    public void setBezeichnung(String bezeichnung) {
        this.bezeichnung = bezeichnung;
    }

    public List<Katze> getKatzen() {
        return katzen;
    }

    public void setKatzen(List<Katze> katzen) {
        this.katzen = katzen;
    }
}
